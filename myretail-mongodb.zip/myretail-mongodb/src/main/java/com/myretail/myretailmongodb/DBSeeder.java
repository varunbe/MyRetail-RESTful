package com.myretail.myretailmongodb;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DBSeeder implements CommandLineRunner
{
    private ProductRepository productRepository;

    public DBSeeder(ProductRepository productRepository)
    {
        this.productRepository = productRepository;
    }

    @Override
    public void run(String... strings) throws Exception
    {
        Product okja = new Product(
                "15114500",
                "Okja",
                new Price(9.49, "USD")
        );
        Product mudbound = new Product(
                "15114501",
                "Mudbound",
                new Price(10.49, "USD")
        );
        Product babby = new Product(
                "15114502",
                "Babby Sitter",
                new Price(11.49, "USD")
        );
        Product beast = new Product(
                "15114503",
                "Beast of No Nation",
                new Price(9.49, "USD")
        );
        Product one = new Product(
                "15114504",
                "1922",
                new Price(10.49, "USD")
        );
        Product bright = new Product(
                "15114505",
                "Bright",
                new Price(12.49, "USD")
        );

        //Drop all Products
        this.productRepository.deleteAll();

        //Add Products to database
        List<Product> products = Arrays.asList(okja,mudbound,babby,beast,one,bright);
        this.productRepository.save(products);
    }
}
