package com.myretail.myretailmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyretailMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyretailMongodbApplication.class, args);
	}
}
